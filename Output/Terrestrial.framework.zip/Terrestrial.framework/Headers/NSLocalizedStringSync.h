//
//  NSLocalizedStringImport.h
//  Terrestrial
//
//  Created by MrMambwe on 04/10/2015.
//  Copyright (c) 2015 Terrestrial. All rights reserved.
//

#ifndef Terrestrial_NSLocalizedStringSync_h
#define Terrestrial_NSLocalizedStringSync_h

#endif

#define NSLocalizedString(key, comment) \
key.translated